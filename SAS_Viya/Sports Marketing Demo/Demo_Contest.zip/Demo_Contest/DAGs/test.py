from datetime import datetime, timedelta
from airflow import DAG, Dataset
from airflow.sensors.filesystem import FileSensor
from sas_airflow_provider.operators.sas_studio import SASStudioOperator
from sas_airflow_provider.operators.sas_jobexecution import SASJobExecutionOperator
from sas_airflow_provider.operators.sas_create_session import SASComputeCreateSession
from sas_airflow_provider.operators.sas_delete_session import SASComputeDeleteSession

dag = DAG(dag_id="test",
   description="test",
   schedule=None,
   catchup=False)

__task0 = SASComputeCreateSession(task_id="0_create_session",
   compute_context_name="SAS Studio compute context",
   connection_name="sas_default",
   session_name="60ac16c8-4e9f-2b4d-9b23-a3ea66a780cf",
   dag=dag)

__task9999 = SASComputeDeleteSession(task_id="9999_delete_session",
   connection_name="sas_default",
   compute_session_id="{{ ti.xcom_pull(key='compute_session_id', task_ids=['0_create_session'])|first }}",
   dag=dag)

task1 = SASStudioOperator(task_id="1_Sports_Marketing_Promo.flw",
   exec_type="flow",
   path_type="content",
   path="/Public/Demo Contest/Sports Demo/Sports_Marketing_Promo.flw",
   compute_session_id="{{ ti.xcom_pull(key='compute_session_id', task_ids=['0_create_session'])|first }}",
   compute_context="SAS Studio compute context",
   connection_name="sas_default",
   exec_log=True,
   codegen_init_code=False,
   codegen_wrap_code=False,
   trigger_rule='all_success',
   dag=dag)

__task0 >> task1
task1 >> __task9999
